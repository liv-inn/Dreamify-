const clientId = "de129d0c7fa34b6a8388a38a864950bb";
const redirectUri = "http://127.0.0.1:5500/pages/index.html"; // Certifique-se de que este é o URI correto
const scopes = "playlist-modify-public playlist-modify-private"; // Permissões para criar e editar playlists

document.getElementById('login-button').addEventListener('click', () => {
    const authUrl = `https://accounts.spotify.com/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scopes)}`;
    window.location.href = authUrl;  // Redireciona para autenticação
});

// Obtém o código de autorização da URL após redirecionamento
const urlParams = new URLSearchParams(window.location.search);
console.log("URL atual:", window.location.href);  // Para verificar a URL
const authorizationCode = urlParams.get('code');

if (authorizationCode) {
    console.log("Código de autorização obtido:", authorizationCode); // Adicione este log

    // Parâmetros da requisição para obter o token de acesso
    const clientSecret = "45947f1d4423422e91b8657bd4411120";  // Substitua pelo seu Client Secret

    const authString = btoa(`${clientId}:${clientSecret}`);

    fetch('https://accounts.spotify.com/api/token', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${authString}`
        },
        body: `grant_type=authorization_code&code=${authorizationCode}&redirect_uri=${encodeURIComponent(redirectUri)}`
    })
    .then(response => {
        if (!response.ok) throw new Error('Erro ao obter o token de acesso');
        return response.json();
    })
    .then(data => {
        console.log("Token de Acesso:", data.access_token);
        // Armazene o token ou use-o diretamente para fazer outras requisições à API
    })
    .catch(error => console.error('Erro:', error));
} else {
    console.log("Código de autorização não encontrado na URL");
}
